* Weather data is provided by [OpenWeatherMap](http://openweathermap.org/).

* The weather icons in the `SVG` folder are part of [Tempestacons](https://github.com/zagortenay333/Tempestacons) / [CC BY-SA 4.0](https://creativecommons.org/licenses/by/4.0/).

* [Roboto](https://www.google.com/fonts/specimen/Roboto) font used in preview.
